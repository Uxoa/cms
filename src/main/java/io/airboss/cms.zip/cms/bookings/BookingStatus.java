package io.airboss.cms.bookings;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
